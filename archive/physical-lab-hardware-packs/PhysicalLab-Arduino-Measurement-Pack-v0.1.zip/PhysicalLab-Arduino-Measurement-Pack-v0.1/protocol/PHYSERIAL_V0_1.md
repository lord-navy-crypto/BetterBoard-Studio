# Physical Lab Serial Protocol v0.1

## Transport
- USB serial
- 115200 baud
- ASCII numeric CSV
- one sample/event per line
- no header line
- no comments/debug text during capture

## Compatibility
Physical Lab serial capture v1 parses:
    float(line.split(',')[-1])

Therefore:
- the final field MUST be numeric;
- the final field is the primary observable;
- extra columns are forward-compatible metadata/channels for a future schema-aware capture v2.

## Recommended line patterns

Magnetometer:
    time_ms,Bx_uT,By_uT,Bz_uT

Generic analog:
    time_ms,adc_counts

Photogate:
    event_time_us,period_us

RPM:
    time_ms,rpm

Encoder:
    time_ms,count,angle_deg

Synthetic:
    time_ms,value

## Scientific boundary
Serial acquisition proves only that bytes were captured.
Sensor accuracy, calibration, timing uncertainty, alignment, environmental correction,
traceability, model-form uncertainty and experimental validation must be established separately.
