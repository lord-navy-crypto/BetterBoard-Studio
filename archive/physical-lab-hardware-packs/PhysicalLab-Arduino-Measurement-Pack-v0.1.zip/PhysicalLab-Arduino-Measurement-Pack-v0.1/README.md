# Physical Lab Arduino Measurement Pack v0.1

Purpose: reusable, low-voltage Arduino UNO R3 acquisition firmware for Physical Lab.

Current compatibility target:
- Arduino UNO R3 / compatible (`arduino:avr:uno`)
- Physical Lab serial capture v1
- 115200 baud
- numeric-only CSV lines
- no serial headers or debug text during acquisition

Important Physical Lab v1 compatibility rule:
Physical Lab's current serial capture keeps the LAST comma-separated numeric field.
Therefore every firmware puts its primary observable in the last column.

Firmware included:
1. MagneticField_MLX90393
2. AnalogDAQ
3. PhotogateTimer
4. PulseRPM
5. QuadratureEncoder
6. SyntheticSignal
7. I2CScanner (diagnostic utility; not for Physical Lab capture)

Planned later after hardware selection:
- IMU / accelerometer vibration firmware
- load-cell / force firmware
- temperature firmware
- schema-aware multichannel Serial Capture v2

Compile example:
    arduino-cli compile --fqbn arduino:avr:uno firmware/MagneticField_MLX90393

No board is needed for compilation.
A board and USB data cable are only needed for port detection, upload, and real serial acquisition.
