# Physical Lab measurement mapping

| Physical Lab area | Real observable(s) | Recommended acquisition path | Firmware |
|---|---|---|---|
| Numerical Error Analysis | sampled x(t), theta(t), ADC series, event times | reuse measured time series for differentiation/integration studies | AnalogDAQ / Encoder / Photogate |
| Ising Monte Carlo | no direct Arduino validation target | published/reference data first; field/temperature only as indirect comparison | defer |
| Random Walk & Monte Carlo | x(t), y(t), step/event timing | camera tracking or wheel/position encoders | Encoder + future tracking adapter |
| Nonlinear Dynamics & Chaos | theta(t), theta1/2(t), event times, drive phase | encoder / photogate / future IMU | Encoder / Photogate |
| Oscillation & Integration | x(t), theta(t), period, frequency, acceleration | photogate / encoder / future IMU | Photogate / Encoder |
| RADIA Magnet Studio | Bx, By, Bz vs position | 3-axis magnetometer / Hall probe | MagneticField_MLX90393 |
| Radiation Platform | measured magnetic field propagated into model | use measured field data, not direct radiation sensing | MagneticField_MLX90393 |
| Kerr Geodesics | observational/reference astrophysical data | external dataset adapter, not Arduino | none |
| Sun-Jupiter-Saturn | ephemeris / orbital reference data | external ephemeris adapter, not Arduino | none |
| Multilayer Honeycomb Lattice | vibration/acceleration/displacement/force in mechanical analogue | future accelerometer / force / tracking | future IMU/force |
| RADIA Runtime | no measurement itself | computational provider | none |
| Chrono::Modal Runtime | future modal response: acceleration/displacement/force | future accelerometer / force / drive reference | future IMU/force |
| VAMPIRE Runtime | future indirect temperature/field/macroscopic response comparison | reference datasets / field + temperature, not atom-level sensing | defer |

Priority order:
1. Magnetic field
2. Photogate timing
3. Encoder angle / displacement
4. Accelerometer vibration
5. Force / load
6. Temperature
7. Camera/object tracking
8. External observational datasets
