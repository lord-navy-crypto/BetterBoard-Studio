// Generic low-voltage analog DAQ for Arduino UNO R3.
// Connect only signals within the board's allowed analog-input range.
// Calibration from ADC counts to a physical unit belongs in Physical Lab.

const uint8_t ANALOG_PIN = A0;
const unsigned long SAMPLE_INTERVAL_MS = 10; // ~100 Hz
unsigned long last_sample_ms = 0;

void setup() {
  Serial.begin(115200);
}

void loop() {
  const unsigned long now = millis();
  if (now - last_sample_ms < SAMPLE_INTERVAL_MS) {
    return;
  }
  last_sample_ms = now;

  const int raw = analogRead(ANALOG_PIN);

  // time_ms,adc_counts
  Serial.print(now);
  Serial.print(',');
  Serial.println(raw);
}
