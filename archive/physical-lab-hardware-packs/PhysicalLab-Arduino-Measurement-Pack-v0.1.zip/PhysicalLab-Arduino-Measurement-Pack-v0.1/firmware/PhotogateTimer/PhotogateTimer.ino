// Event-timing firmware for a digital photogate / break-beam receiver.
// Default: sensor output on digital pin 2.
// Physical Lab v1 consumes period_us (last field).

const uint8_t GATE_PIN = 2;

volatile unsigned long event_time_us = 0;
volatile unsigned long previous_event_us = 0;
volatile unsigned long period_us = 0;
volatile bool new_event = false;

void onGate() {
  const unsigned long now = micros();

  // Simple debounce / double-trigger guard: ignore events within 2 ms.
  if (previous_event_us != 0 && (now - previous_event_us) < 2000UL) {
    return;
  }

  event_time_us = now;
  if (previous_event_us != 0) {
    period_us = now - previous_event_us;
    new_event = true;
  }
  previous_event_us = now;
}

void setup() {
  Serial.begin(115200);
  pinMode(GATE_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(GATE_PIN), onGate, FALLING);
}

void loop() {
  noInterrupts();
  const bool ready = new_event;
  const unsigned long t = event_time_us;
  const unsigned long p = period_us;
  if (ready) {
    new_event = false;
  }
  interrupts();

  if (ready) {
    // event_time_us,period_us
    Serial.print(t);
    Serial.print(',');
    Serial.println(p);
  }
}
