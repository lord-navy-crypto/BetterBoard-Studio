// Basic quadrature encoder acquisition for Arduino UNO R3.
// Encoder A -> D2, Encoder B -> D3.
// Set COUNTS_PER_REVOLUTION to the effective quadrature count per full revolution.

const uint8_t ENC_A = 2;
const uint8_t ENC_B = 3;
const long COUNTS_PER_REVOLUTION = 600; // replace with actual encoder value
const unsigned long SAMPLE_INTERVAL_MS = 10; // ~100 Hz

volatile long encoder_count = 0;
unsigned long last_sample_ms = 0;

void onA() {
  const bool a = digitalRead(ENC_A);
  const bool b = digitalRead(ENC_B);
  encoder_count += (a == b) ? 1 : -1;
}

void onB() {
  const bool a = digitalRead(ENC_A);
  const bool b = digitalRead(ENC_B);
  encoder_count += (a != b) ? 1 : -1;
}

void setup() {
  Serial.begin(115200);
  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(ENC_A), onA, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_B), onB, CHANGE);
}

void loop() {
  const unsigned long now = millis();
  if (now - last_sample_ms < SAMPLE_INTERVAL_MS) {
    return;
  }
  last_sample_ms = now;

  noInterrupts();
  const long count = encoder_count;
  interrupts();

  const float angle_deg =
      360.0f * float(count) / float(COUNTS_PER_REVOLUTION);

  // time_ms,count,angle_deg
  // Physical Lab v1 consumes angle_deg.
  Serial.print(now);
  Serial.print(',');
  Serial.print(count);
  Serial.print(',');
  Serial.println(angle_deg, 4);
}
