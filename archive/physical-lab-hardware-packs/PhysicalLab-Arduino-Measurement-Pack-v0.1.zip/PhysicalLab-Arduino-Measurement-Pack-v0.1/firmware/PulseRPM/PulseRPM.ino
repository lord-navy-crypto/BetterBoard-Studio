// Pulse/RPM acquisition for a Hall switch, optical encoder or similar digital pulse source.
// Default input: digital pin 2.
// Configure PULSES_PER_REVOLUTION for the actual sensor/encoder geometry.

const uint8_t PULSE_PIN = 2;
const float PULSES_PER_REVOLUTION = 1.0f;

volatile unsigned long last_pulse_us = 0;
volatile unsigned long pulse_period_us = 0;
volatile bool new_period = false;

void onPulse() {
  const unsigned long now = micros();
  if (last_pulse_us != 0) {
    const unsigned long dt = now - last_pulse_us;
    if (dt > 1000UL) { // reject implausibly close duplicate edges (<1 ms)
      pulse_period_us = dt;
      new_period = true;
    }
  }
  last_pulse_us = now;
}

void setup() {
  Serial.begin(115200);
  pinMode(PULSE_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(PULSE_PIN), onPulse, FALLING);
}

void loop() {
  noInterrupts();
  const bool ready = new_period;
  const unsigned long dt = pulse_period_us;
  if (ready) {
    new_period = false;
  }
  interrupts();

  if (ready && dt > 0 && PULSES_PER_REVOLUTION > 0.0f) {
    const float rpm = 60000000.0f / (float(dt) * PULSES_PER_REVOLUTION);

    // time_ms,rpm
    Serial.print(millis());
    Serial.print(',');
    Serial.println(rpm, 4);
  }
}
