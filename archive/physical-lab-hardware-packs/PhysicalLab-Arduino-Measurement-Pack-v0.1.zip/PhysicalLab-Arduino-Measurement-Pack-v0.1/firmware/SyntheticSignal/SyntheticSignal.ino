// Hardware-independent serial-path test.
// Generates a deterministic sine-like test signal for Physical Lab capture.
// No sensor is required, but an Arduino board is required to upload/run it.

#include <math.h>

const unsigned long SAMPLE_INTERVAL_MS = 20; // 50 Hz
unsigned long last_sample_ms = 0;

void setup() {
  Serial.begin(115200);
}

void loop() {
  const unsigned long now = millis();
  if (now - last_sample_ms < SAMPLE_INTERVAL_MS) {
    return;
  }
  last_sample_ms = now;

  const float t = now / 1000.0f;
  const float value = sin(2.0f * PI * 0.5f * t);

  // time_ms,value
  Serial.print(now);
  Serial.print(',');
  Serial.println(value, 6);
}
