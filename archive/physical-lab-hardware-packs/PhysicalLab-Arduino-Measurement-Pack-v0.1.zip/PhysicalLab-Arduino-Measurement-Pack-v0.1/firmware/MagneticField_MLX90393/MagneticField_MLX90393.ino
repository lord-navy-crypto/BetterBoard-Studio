#include <Wire.h>
#include <Adafruit_MLX90393.h>

Adafruit_MLX90393 mag;

const unsigned long SAMPLE_INTERVAL_MS = 50; // ~20 Hz
unsigned long last_sample_ms = 0;

void failSensor() {
  // Keep the data stream numeric-only. Signal failure with the built-in LED.
  while (true) {
    digitalWrite(LED_BUILTIN, HIGH);
    delay(150);
    digitalWrite(LED_BUILTIN, LOW);
    delay(150);
  }
}

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  Serial.begin(115200);

  if (!mag.begin_I2C()) {
    failSensor();
  }
}

void loop() {
  const unsigned long now = millis();
  if (now - last_sample_ms < SAMPLE_INTERVAL_MS) {
    return;
  }
  last_sample_ms = now;

  float bx, by, bz;
  if (mag.readData(&bx, &by, &bz)) {
    // time_ms,Bx_uT,By_uT,Bz_uT
    // Physical Lab serial v1 consumes Bz (last field).
    Serial.print(now);
    Serial.print(',');
    Serial.print(bx, 4);
    Serial.print(',');
    Serial.print(by, 4);
    Serial.print(',');
    Serial.println(bz, 4);
  }
}
