# Physical Lab Hardware Pack v0.4

Reusable low-voltage Arduino UNO R3 acquisition/control firmware for Physical Lab.

## Main firmware

1. MagneticField_MLX90393
   - RADIA Magnet Studio
   - Radiation Platform
   - Output: time_us,Bx_uT,By_uT,Bz_uT,primary_uT

2. PhotogateTimer
   - Oscillation & Integration
   - Nonlinear Dynamics & Chaos
   - Output: event_us,period_us,frequency_hz

3. QuadratureEncoder
   - Oscillation & Integration
   - Nonlinear Dynamics & Chaos
   - Output: time_us,count,angle_deg

4. Accelerometer_ADXL345
   - Multilayer Honeycomb Lattice mechanical analogue
   - Oscillation & Integration
   - future Chrono::Modal experiments
   - Output: time_us,ax,ay,az,primary_mps2

5. AnalogDAQ
   - Generic low-voltage analog sensors
   - Numerical Error Analysis as a reusable measured-data source
   - Output: time_us,adc_counts

6. RandomWalkRobot
   - Random Walk & Monte Carlo physical experiment
   - Arduino produces bounded low-speed stochastic commands.
   - Real x(t),y(t) should be measured independently, preferably by camera tracking.
   - Output: time_ms,step_index,turn_quarters,move_ms

7. SyntheticSignal
   - End-to-end serial-path test
   - Output: time_us,value

## Utilities

- I2CScanner
- PulseRPM

## Serial compatibility

Physical Lab serial capture v1 currently consumes the last comma-separated numeric field.
All acquisition firmware therefore keeps a primary numeric observable as the last field.

No board is needed to compile.
USB is needed only for detection, upload and actual acquisition.
