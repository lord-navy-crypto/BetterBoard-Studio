# Physical Lab Arduino Measurement Pack v0.2

A deliberately small set of reusable low-voltage acquisition firmware for Physical Lab.

## Main firmware
1. MagneticField_MLX90393 — RADIA / Radiation measured-field path
2. PhotogateTimer — Oscillation / Chaos timing
3. QuadratureEncoder — Oscillation / Chaos angle
4. Accelerometer_ADXL345 — Honeycomb mechanical analogue / Oscillation / future Chrono::Modal
5. AnalogDAQ — generic calibrated sensor input
6. SyntheticSignal — end-to-end serial test

## Utilities
- I2CScanner
- PulseRPM

## Deliberately not given dedicated Arduino firmware
- Random Walk: camera/object tracking is the scientifically cleaner real-data path
- Ising: current dimensionless model is not a calibrated material experiment
- Kerr: observational/reference data
- Sun-Jupiter-Saturn: ephemeris/reference data
- VAMPIRE: deferred
- Kohn-Sham/DFT: not present in current Physical Lab main; if later added, external spectroscopy/material datasets are more appropriate than Arduino

## ADXL345 dependency
Install before compiling the accelerometer firmware:

    arduino-cli lib install "Adafruit ADXL345"

Compile without a connected board:

    arduino-cli compile --fqbn arduino:avr:uno firmware/Accelerometer_ADXL345

## Serial compatibility
Physical Lab serial capture v1 currently consumes the final comma-separated numeric field.
The firmware therefore keeps its primary observable in the final field while preserving
extra columns for a future schema-aware Serial Capture v2.
