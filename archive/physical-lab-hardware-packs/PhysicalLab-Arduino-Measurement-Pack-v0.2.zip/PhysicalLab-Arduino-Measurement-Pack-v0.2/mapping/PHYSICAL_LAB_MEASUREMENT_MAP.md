# Physical Lab measurement mapping — v0.2

This list intentionally includes only measurement paths that are scientifically defensible.

| Physical Lab area | Real observable(s) | Acquisition path | Status |
|---|---|---|---|
| RADIA Magnet Studio | Bx, By, Bz vs position | MLX90393 / quantitative magnetometer | READY |
| Radiation Platform | measured magnetic field propagated through model | same magnetic-field dataset | READY, indirect |
| Oscillation & Integration | period, frequency, theta(t), acceleration | photogate / encoder / accelerometer | READY |
| Nonlinear Dynamics & Chaos | theta(t), event timing, finite-window response | encoder / photogate / accelerometer | READY |
| Numerical Error Analysis | measured sampled series used for differentiation/integration/noise studies | reuse any appropriate measured time series | READY, shared |
| Multilayer Honeycomb Lattice | vibration acceleration / local spectrum of a mechanical analogue | ADXL345 accelerometer | READY as mechanical analogue |
| Chrono::Modal Runtime | modal-response acceleration / resonance frequencies | ADXL345 accelerometer | READY as future runtime consumer |
| Random Walk & Monte Carlo | x(t), y(t), MSD / first-passage | camera/object tracking preferred | DEFER: valid, but not Arduino priority |
| Ising Monte Carlo | no direct Arduino observable for current dimensionless model | reference datasets | NO dedicated Arduino firmware |
| Kerr Geodesics | astrophysical observational/reference data | external datasets | NO Arduino firmware |
| Sun-Jupiter-Saturn | ephemeris / observation | external ephemeris | NO Arduino firmware |
| VAMPIRE Runtime | atomistic magnetic model | external/reference data, possibly indirect macro comparison | intentionally deferred |
| Kohn-Sham / DFT | not present in current Physical Lab main; if added, use appropriate materials/spectroscopy datasets | external dataset adapter | NO Arduino firmware |

Scientific boundary for Honeycomb:
The Physical Lab honeycomb model is a reduced-unit lattice-dynamics model, not calibrated graphene.
Accelerometer data should therefore be labelled a mechanical analogue until a physical-unit mapping,
force constants, geometry, calibration and uncertainty model are explicitly established.
