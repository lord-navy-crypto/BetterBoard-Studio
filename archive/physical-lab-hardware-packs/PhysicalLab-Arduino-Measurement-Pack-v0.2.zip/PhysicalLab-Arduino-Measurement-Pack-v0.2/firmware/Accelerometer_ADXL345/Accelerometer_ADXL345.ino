#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>

// Physical Lab reference accelerometer firmware.
// Target use:
//   - mechanical honeycomb analogue vibration measurements
//   - Oscillation / modal-response experiments
//   - future Chrono::Modal measurement comparison
//
// Serial protocol:
//   time_us,ax_mps2,ay_mps2,az_mps2
//
// Physical Lab serial capture v1 consumes the LAST numeric field,
// therefore az_mps2 is the current primary observable.
// A future schema-aware capture v2 can preserve all three axes.

Adafruit_ADXL345_Unified accel = Adafruit_ADXL345_Unified(34501);

const unsigned long SAMPLE_INTERVAL_US = 10000UL; // ~100 Hz
unsigned long last_sample_us = 0;

void failSensor() {
  pinMode(LED_BUILTIN, OUTPUT);
  while (true) {
    digitalWrite(LED_BUILTIN, HIGH);
    delay(150);
    digitalWrite(LED_BUILTIN, LOW);
    delay(150);
  }
}

void setup() {
  Serial.begin(115200);

  if (!accel.begin()) {
    // Keep acquisition stream numeric-only.
    failSensor();
  }

  accel.setRange(ADXL345_RANGE_16_G);
  accel.setDataRate(ADXL345_DATARATE_100_HZ);
}

void loop() {
  const unsigned long now = micros();

  if ((unsigned long)(now - last_sample_us) < SAMPLE_INTERVAL_US) {
    return;
  }
  last_sample_us = now;

  sensors_event_t event;
  accel.getEvent(&event);

  // Units supplied by Adafruit Unified Sensor API: m/s^2
  // time_us,ax_mps2,ay_mps2,az_mps2
  Serial.print(now);
  Serial.print(',');
  Serial.print(event.acceleration.x, 5);
  Serial.print(',');
  Serial.print(event.acceleration.y, 5);
  Serial.print(',');
  Serial.println(event.acceleration.z, 5);
}
