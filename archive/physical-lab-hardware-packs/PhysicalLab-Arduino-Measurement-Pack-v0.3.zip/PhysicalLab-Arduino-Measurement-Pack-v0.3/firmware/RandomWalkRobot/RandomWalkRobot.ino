// Physical Lab Random Walk Robot v0.1
// Target: small, low-speed tabletop differential-drive robot.
// Purpose: create a reproducible physical random-walk trajectory.
// True x(t), y(t) should preferably be measured by camera/object tracking.
// This firmware emits the commanded random step metadata over Serial.
//
// Generic dual H-bridge pin assignment (adjust to your board/driver):
const uint8_t LEFT_PWM  = 5;
const uint8_t LEFT_DIR  = 4;
const uint8_t RIGHT_PWM = 6;
const uint8_t RIGHT_DIR = 7;

const uint8_t MAX_PWM = 110;  // intentionally low-speed
const unsigned long MIN_MOVE_MS = 250;
const unsigned long MAX_MOVE_MS = 700;
const unsigned long TURN_MS_90 = 260; // apparatus-specific; calibrate experimentally

unsigned long step_index = 0;

void setMotor(uint8_t pwmPin, uint8_t dirPin, int speedValue) {
  bool forward = speedValue >= 0;
  int magnitude = abs(speedValue);
  if (magnitude > MAX_PWM) magnitude = MAX_PWM;
  digitalWrite(dirPin, forward ? HIGH : LOW);
  analogWrite(pwmPin, magnitude);
}

void stopRobot() {
  analogWrite(LEFT_PWM, 0);
  analogWrite(RIGHT_PWM, 0);
}

void turnInPlace(int direction, unsigned long duration_ms) {
  // direction = +1 or -1
  setMotor(LEFT_PWM, LEFT_DIR,  direction * MAX_PWM);
  setMotor(RIGHT_PWM, RIGHT_DIR, -direction * MAX_PWM);
  delay(duration_ms);
  stopRobot();
}

void moveForward(unsigned long duration_ms) {
  setMotor(LEFT_PWM, LEFT_DIR, MAX_PWM);
  setMotor(RIGHT_PWM, RIGHT_DIR, MAX_PWM);
  delay(duration_ms);
  stopRobot();
}

void setup() {
  pinMode(LEFT_PWM, OUTPUT);
  pinMode(LEFT_DIR, OUTPUT);
  pinMode(RIGHT_PWM, OUTPUT);
  pinMode(RIGHT_DIR, OUTPUT);
  stopRobot();

  Serial.begin(115200);

  // Seed is intentionally derived from a floating analog pin.
  // For strict reproducibility, replace with a fixed integer seed.
  randomSeed(analogRead(A0));
}

void loop() {
  // Choose one of four nominal directions relative to current heading:
  // 0 = straight, 1 = left 90 deg, 2 = right 90 deg, 3 = reverse 180 deg.
  const long choice = random(0, 4);
  int turn_quarters = 0;

  if (choice == 1) {
    turn_quarters = -1;
    turnInPlace(-1, TURN_MS_90);
  } else if (choice == 2) {
    turn_quarters = 1;
    turnInPlace(1, TURN_MS_90);
  } else if (choice == 3) {
    turn_quarters = 2;
    turnInPlace(1, 2 * TURN_MS_90);
  }

  const unsigned long move_ms = random(MIN_MOVE_MS, MAX_MOVE_MS + 1);
  moveForward(move_ms);

  ++step_index;

  // time_ms,step_index,turn_quarters,move_ms
  // Physical Lab serial v1 consumes move_ms (last field).
  // A future Serial Capture v2 can preserve all metadata.
  Serial.print(millis());
  Serial.print(',');
  Serial.print(step_index);
  Serial.print(',');
  Serial.print(turn_quarters);
  Serial.print(',');
  Serial.println(move_ms);

  delay(250);
}
