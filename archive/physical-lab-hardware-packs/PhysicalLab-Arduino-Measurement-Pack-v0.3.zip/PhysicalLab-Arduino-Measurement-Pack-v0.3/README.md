# Physical Lab Arduino Measurement Pack v0.3

A deliberately small set of reusable, low-voltage acquisition/control firmware for Physical Lab.

## Main firmware
1. MagneticField_MLX90393 — RADIA / Radiation measured-field path
2. PhotogateTimer — Oscillation / Chaos timing
3. QuadratureEncoder — Oscillation / Chaos angle
4. Accelerometer_ADXL345 — Honeycomb mechanical analogue / Oscillation / future Chrono::Modal
5. AnalogDAQ — generic calibrated sensor input
6. RandomWalkRobot — low-speed tabletop physical random-walk command generator
7. SyntheticSignal — end-to-end serial test

## Utilities
- I2CScanner
- PulseRPM

## Important Random Walk note
The robot firmware creates the stochastic motion commands, but the most scientifically useful
measurement is the actual trajectory x(t), y(t). Prefer camera/object tracking (or calibrated
position sensing) for that measurement. Do not treat motor command duration as true displacement.

## Deliberately not given dedicated Arduino firmware
- Ising: current dimensionless model is not a calibrated material experiment
- Kerr: observational/reference data
- Sun-Jupiter-Saturn: ephemeris/reference data
- VAMPIRE: deferred
- Kohn-Sham/DFT: not present in current Physical Lab main; external spectroscopy/material datasets are more appropriate than Arduino

## Extra library for accelerometer
    arduino-cli lib install "Adafruit ADXL345"

Compile examples without a connected board:
    arduino-cli compile --fqbn arduino:avr:uno firmware/MagneticField_MLX90393
    arduino-cli compile --fqbn arduino:avr:uno firmware/Accelerometer_ADXL345
    arduino-cli compile --fqbn arduino:avr:uno firmware/RandomWalkRobot
